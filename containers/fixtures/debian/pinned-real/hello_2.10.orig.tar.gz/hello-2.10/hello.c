/* Synthetic upstream hello — a tiny hello-world used by
 * the IronMaint pinned-real test fixture (Phase 2.0-D).
 *
 * This file is the upstream source of the synthetic orig
 * tarball committed at
 * containers/fixtures/debian/pinned-real/hello_2.10.orig.tar.gz.
 * It is *not* the real Debian hello source — it is a
 * hermetic replacement so the fixture does not need a
 * network fetch. The METADATA file in the fixture records
 * the tarball's SHA-256.
 */
#include <stdio.h>
int main(void) { puts("hello"); return 0; }
